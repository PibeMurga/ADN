
package excepciones;


public class ExcepcionInsertarAfiliado extends Exception {

    
    public ExcepcionInsertarAfiliado() {
    }

    
    public ExcepcionInsertarAfiliado(String msg) {
        super(msg);
    }
}


package excepciones;


public class ExcepcionCedulaNoEncontrada extends Exception {

    
    public ExcepcionCedulaNoEncontrada() {
    }

    
    public ExcepcionCedulaNoEncontrada(String msg) {
        super(msg);
    }
}

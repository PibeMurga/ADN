
package excepciones;


public class ExcepcionConsultaNegocio extends Exception {

   
    public ExcepcionConsultaNegocio() {
    }

   
    public ExcepcionConsultaNegocio(String msg) {
        super(msg);
    }
}



package excepciones;

public class ExcepcionCerrarConexion extends Exception {

   
    public ExcepcionCerrarConexion() {
    }

  
    public ExcepcionCerrarConexion(String msg) {
        super(msg);
    }
}


package excepciones;

public class ExcepcionConsultaCedula extends Exception {

   
    public ExcepcionConsultaCedula() {
    }

    
    public ExcepcionConsultaCedula(String msg) {
        super(msg);
    }
}

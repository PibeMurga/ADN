
package excepciones;


public class ExcepcionInsertarFactura extends Exception {

    
    public ExcepcionInsertarFactura() {
    }

    
    public ExcepcionInsertarFactura(String msg) {
        super(msg);
    }
}

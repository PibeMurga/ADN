
package excepciones;


public class ExcepcionInactivarAfiliado extends Exception {

   
    public ExcepcionInactivarAfiliado() {
    }

    
    public ExcepcionInactivarAfiliado(String msg) {
        super(msg);
    }
}

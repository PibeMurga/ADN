
package excepciones;
public class ExcepcionConectar extends Exception {

    public ExcepcionConectar() {
    }

    public ExcepcionConectar(String msg) {
        super(msg);
    }
}

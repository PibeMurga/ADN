
package excepciones;


public class ExcepcionListarAfiliados extends Exception {

    
    public ExcepcionListarAfiliados() {
    }

   
    public ExcepcionListarAfiliados(String msg) {
        super(msg);
    }
}

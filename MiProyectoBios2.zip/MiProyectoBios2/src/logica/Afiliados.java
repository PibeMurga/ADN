
package logica;

import java.util.ArrayList;


public class Afiliados {
    
    private ArrayList<Afiliado> lista = new ArrayList();

    public ArrayList<Afiliado> getListaAfiliados() {
        return lista;
    }

    public void setListaAfiliados(ArrayList<Afiliado> lista) {
        this.lista = lista;
    }
    
    public void setAfiliado(Afiliado afiliado){
        lista.add(afiliado);
    }
    
    
    public int size() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public Afiliado get(int i) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}

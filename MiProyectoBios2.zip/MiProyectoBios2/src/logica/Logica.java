
package logica;

import excepciones.ExcepcionCedulaNoEncontrada;
import excepciones.ExcepcionCerrarConexion;
import excepciones.ExcepcionConectar;
import excepciones.ExcepcionConsultaCedula;
import excepciones.ExcepcionConsultaNegocio;
import excepciones.ExcepcionInactivarAfiliado;
import excepciones.ExcepcionInsertarAfiliado;
import excepciones.ExcepcionListarAfiliados;
import persistencia.PersistenciaAfiliados;
import persistencia.PersistenciaNegocios;
import persistencia.PersistenciaUsuarios;


public class Logica {
    
    public static String consultarUsuario (Usuario usuario) throws ExcepcionConectar, ExcepcionCerrarConexion{
        return PersistenciaUsuarios.consultar(usuario);
    }
    
    public static Afiliados listadoAfiliadosActivos() throws ExcepcionConectar, ExcepcionCerrarConexion, ExcepcionListarAfiliados{
        return PersistenciaAfiliados.listarAfiliadosActivos();
    }
    
    public static Afiliado consultaAfiliadoPorCedula(Afiliado afiliado) throws ExcepcionConectar, ExcepcionCerrarConexion, ExcepcionConsultaCedula, ExcepcionCedulaNoEncontrada{
        return PersistenciaAfiliados.consultaCedula(afiliado);
    }
    
    public static String inactivarAfiliado(Afiliado afiliado) throws ExcepcionConectar, ExcepcionInactivarAfiliado, ExcepcionCerrarConexion{
        return PersistenciaAfiliados.inactivarAfiliado(afiliado);
    }
    
    public static Negocios listaNegocios() throws ExcepcionConectar, ExcepcionConsultaNegocio, ExcepcionCerrarConexion{
        return PersistenciaNegocios.listaNegocios();
    }
    
    public static void insertarAfiliado(Afiliado afiliado) throws ExcepcionConectar, ExcepcionInsertarAfiliado, ExcepcionCerrarConexion{
        PersistenciaAfiliados.insertarAfiliado(afiliado);
    }
    
}

package logica;

public class Negocio {
    
    private String id;
    private String nombre;
    private String id_rubro;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getId_rubro() {
        return id_rubro;
    }

    public void setId_rubro(String id_rubro) {
        this.id_rubro = id_rubro;
    }
    
    public String toString(){
        return nombre;
    }
    
    
}

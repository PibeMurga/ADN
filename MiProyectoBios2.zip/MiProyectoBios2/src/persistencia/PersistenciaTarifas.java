package persistencia;

import excepciones.*;
import java.sql.*;
import logica.Tarifa;


public class PersistenciaTarifas {

    private static final String CONSULTA_FECHA = "SELECT * FROM adn.tarifas WHERE fecha=?;";
    private static final String ULTIMA_TARIFA = "SELECT * FROM adn.tarifas WHERE fecha<=? order by fecha desc limit 1"; 
    
    public static Tarifa getTarifa(Date fecha) throws ExcepcionConectar, ExcepcionCerrarConexion {
        ResultSet resultado = null;
        Connection conexion = PersistenciaConexion.Conectar();
        Tarifa tarifa = new Tarifa();
        try {
            PreparedStatement consultaPreparada = conexion.prepareStatement(ULTIMA_TARIFA);
            consultaPreparada.setDate(1, fecha);
            resultado = consultaPreparada.executeQuery();
            
            tarifa.setFecha(resultado.getDate("fecha"));
            tarifa.setMatricula(resultado.getDouble("matricula"));
            tarifa.setCuota(resultado.getDouble("cuota"));
            
        } catch (SQLException ex) {
            throw new ExcepcionConectar("No se pudo realizar la consulta");

        } finally {
            PersistenciaConexion.cerrarConexion();
        }
             
        return tarifa;
    }

    static Tarifa getTarifa(java.util.Date fechaFactura) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
}

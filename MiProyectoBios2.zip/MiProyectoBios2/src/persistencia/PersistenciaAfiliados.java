package persistencia;

import excepciones.*;
import java.sql.*;
import java.util.ArrayList;
import logica.Afiliado;
import logica.Afiliados;

public class PersistenciaAfiliados {

    private static final String CONSULTA_ACTIVOS = "SELECT * FROM adn.afiliados WHERE estado='activo';";
    private static final String CONSULTA_CEDULA = "SELECT * FROM adn.afiliados WHERE cedula=? and estado='activo';";
    private static final String INACTIVAR = "UPDATE `adn`.`afiliados` SET `estado` = 'inactivo' WHERE (`cedula` = ?);";
    private static final String INSERTAR = "INSERT INTO `adn`.`afiliados` (`cedula`, `nombre`, `apellido`, "
            + "`nacionalidad`, `direccion`, `telefono`, `email`, `nacimiento`, `negocios_idNegocios`, `estado`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    public static Afiliados listarAfiliadosActivos() throws ExcepcionConectar, ExcepcionCerrarConexion, ExcepcionListarAfiliados {
        ArrayList<Afiliado> lista = new ArrayList<>();
        Afiliados afiliados = new Afiliados();
        Connection conexion = PersistenciaConexion.Conectar();

        try {
            PreparedStatement declaracionPreparada = conexion.prepareStatement(CONSULTA_ACTIVOS);
            ResultSet resultado = declaracionPreparada.executeQuery();
            while (resultado.next()) {
                Afiliado afiliado = new Afiliado();
                afiliado.setCedula(resultado.getString("cedula"));
                afiliado.setNombre(resultado.getString("nombre"));
                afiliado.setApellido(resultado.getString("apellido"));
                lista.add(afiliado);
            }
            afiliados.setListaAfiliados(lista);
        } catch (SQLException ex) {
            throw new ExcepcionListarAfiliados("No se pudo listar a los afiliados");
        } finally {
            PersistenciaConexion.cerrarConexion();
        }
        return afiliados;
    }

    public static Afiliado consultaCedula(Afiliado afiliado) throws ExcepcionConectar, ExcepcionCerrarConexion, ExcepcionConsultaCedula, ExcepcionCedulaNoEncontrada {
        ResultSet resultado = null;
        Connection conexion = PersistenciaConexion.Conectar();
        try {
            PreparedStatement consultaPreparada = conexion.prepareStatement(CONSULTA_CEDULA);
            consultaPreparada.setString(1, afiliado.getCedula());
            resultado = consultaPreparada.executeQuery();
            boolean cedulaExiste = false;
            while (resultado.next()) {
                cedulaExiste = true;
                afiliado.setCedula(resultado.getString("cedula"));
                afiliado.setNombre(resultado.getString("nombre"));
                afiliado.setApellido(resultado.getString("apellido"));
                afiliado.setNacionalidad(resultado.getString("nacionalidad"));
                afiliado.setDireccion(resultado.getString("direccion"));
                afiliado.setTelefono(resultado.getString("telefono"));
                afiliado.setEmail(resultado.getString("email"));
                afiliado.setNacimiento(resultado.getString("nacimiento"));
                afiliado.setNegocio(resultado.getString("negocios_idNegocios"));
                afiliado.setEstado(resultado.getString("estado"));
            }
            if (cedulaExiste == false) {
                throw new ExcepcionCedulaNoEncontrada("Cédula no encontrada");
            }
        } catch (SQLException ex) {
            throw new ExcepcionConsultaCedula("No se pudo realizar la consulta por cédula");

        } finally {
            PersistenciaConexion.cerrarConexion();
        }
        return afiliado;
    }

    public static String inactivarAfiliado(Afiliado afiliado) throws ExcepcionConectar, ExcepcionInactivarAfiliado, ExcepcionCerrarConexion {
        int x;
        String mensaje;
        try {
            Connection conexion = PersistenciaConexion.Conectar();
            PreparedStatement consultaPreparada = conexion.prepareStatement(INACTIVAR);

            consultaPreparada.setString(1, afiliado.getCedula());
            x = consultaPreparada.executeUpdate();
            if (x == 0) {
                mensaje = "No se pudo realizar la desafiliación";
            } else {
                mensaje = "Desafiliación realizada correctamente";
            }
        } catch (SQLException ex) {
            throw new ExcepcionInactivarAfiliado("No se pudo realizar la desafiliación");
        }finally {
            PersistenciaConexion.cerrarConexion();
        }
        return mensaje;

    }

    public static void insertarAfiliado(Afiliado afiliado) throws ExcepcionConectar, ExcepcionInsertarAfiliado, ExcepcionCerrarConexion {
        Connection conexion = PersistenciaConexion.Conectar();
        try {
            PreparedStatement consultaPreparada = conexion.prepareStatement(INSERTAR);
            consultaPreparada.setString(1, afiliado.getCedula());
            consultaPreparada.setString(2, afiliado.getNombre());
            consultaPreparada.setString(3, afiliado.getApellido());
            consultaPreparada.setString(4, afiliado.getNacionalidad());
            consultaPreparada.setString(5, afiliado.getDireccion());
            consultaPreparada.setString(6, afiliado.getTelefono());
            consultaPreparada.setString(7, afiliado.getEmail());
            consultaPreparada.setString(8, afiliado.getNacimiento());
            consultaPreparada.setString(9, afiliado.getNegocio());
            consultaPreparada.setString(10, afiliado.getEstado());
            consultaPreparada.executeUpdate();
               
        } catch (SQLException ex) {
            ex.printStackTrace();
            throw new ExcepcionInsertarAfiliado("No se pudo agregar afiliado a la base");
        }finally {
            PersistenciaConexion.cerrarConexion();
        }
    }
}

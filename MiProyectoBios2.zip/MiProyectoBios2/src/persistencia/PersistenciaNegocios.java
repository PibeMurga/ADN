package persistencia;

import excepciones.ExcepcionCerrarConexion;
import excepciones.ExcepcionConectar;
import excepciones.ExcepcionConsultaNegocio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import logica.Negocio;
import logica.Negocios;

public class PersistenciaNegocios {

    private static final String CONSULTA_NEGOCIOS = "SELECT * FROM adn.negocios;";

    public static Negocios listaNegocios() throws ExcepcionConectar, ExcepcionConsultaNegocio, ExcepcionCerrarConexion {
        Negocios negocios = new Negocios();
        ArrayList<Negocio> lista = new ArrayList<>();
        Connection conexion = PersistenciaConexion.Conectar();
        try {
            PreparedStatement declaracionPreparada = conexion.prepareStatement(CONSULTA_NEGOCIOS);
            ResultSet resultado = declaracionPreparada.executeQuery();
            while (resultado.next()) {
                Negocio negocio = new Negocio();
                negocio.setId(resultado.getString("idNegocios"));
                negocio.setNombre(resultado.getString("nombre"));
                negocio.setId_rubro(resultado.getString("Rubros_idRubros"));
                lista.add(negocio);
            }
            negocios.setNegocios(lista);
        } catch (SQLException ex) {
            throw new ExcepcionConsultaNegocio("No se pudo realizar consulta de negocios");
        } finally {
            PersistenciaConexion.cerrarConexion();
        }
        return negocios;
    }

}

package persistencia;

import excepciones.*;
import java.sql.*;
import java.text.ParseException;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import logica.Factura;
import logica.Facturas;
import logica.Tarifa;
import logica.Afiliado;
import logica.Afiliados;

        



public class PersistenciaFacturas {

    private static final String CONSULTA_MENSUAL = "select * from adn.facturas where month(fecha_emision)=? and year(fecha_emision)=?;";
    private static final String CONSULTA_AFILIADO = "SELECT * FROM adn.facturas WHERE afiliadoced=? ;";
    private static final String CONSULTA_ATRASADOS = "SELECT * FROM adn.facturas WHERE fecha_pago is null group by afiliadoced having count(*)>2;";
    private static final String CONSULTA_IMPAGAS_AFILIADO = "SELECT * FROM adn.facturas WHERE afiliadoced=? and fecha_pago is null;";
    private static final String DELETE_MENSUAL = "delete * from adn.facturas where month(fecha_emision)=? and year(fecha_emision)=?;";
    private static final String DELETE_AFILIADO = "delete * from adn.facturas where afiliadoced=? and concepto='cuota' and month(fecha_emision)=? and year(fecha_emision)=?;";
    private static final String INSERTAR_FACTURA = "INSERT INTO adn.facturas` (`afiliadoced`,`fecha_emision`, `concepto`, `importe`) VALUES (?, ?, ?, ?, ?)";
    private static final String PAGAR_FACTURA = "UPDATE adn.facturas SET `fecha_pago` = ? WHERE idfactura=?;";
   
    /**
     *
     * @param mes
     * @param anio
     * @throws ExcepcionConectar
     * @throws ExcepcionInsertarFactura
     * @throws ExcepcionCerrarConexion
     * @throws ExcepcionListarAfiliados
     * @throws java.text.ParseException
     */
    public static void facturacionMensual(int mes, int anio) throws ExcepcionConectar, ExcepcionInsertarFactura, ExcepcionCerrarConexion, ExcepcionListarAfiliados, ParseException {
        Connection conexion = PersistenciaConexion.Conectar();
        Afiliados afiliadosActivos = PersistenciaAfiliados.listarAfiliadosActivos();
        ///String fechaFacturacion = anio + "-" + mes + "-01";
        String fechaFacturacion = "2022-07-01";
        SimpleDateFormat formateador = new SimpleDateFormat("yyyy-MM-dd");
        Date fechaFactura = formateador.parse(fechaFacturacion);
        Tarifa tarifa = PersistenciaTarifas.getTarifa(fechaFactura);
        for (int i=0; i<afiliadosActivos.size(); i++){
            try {
                Afiliado afiliado = afiliadosActivos.get(i);
                PreparedStatement consultaPreparada = conexion.prepareStatement(INSERTAR_FACTURA);
                consultaPreparada.setString(1, afiliado.getCedula());
                consultaPreparada.setDate(2, new java.sql.Date(fechaFactura.getTime()));
                consultaPreparada.setString(3, "CUOTA");
                consultaPreparada.setDouble(4, tarifa.getCuota());
                consultaPreparada.executeUpdate();
            } catch (SQLException ex) {
                throw new ExcepcionInsertarFactura("Error al insertar la factura");
            }finally {
                PersistenciaConexion.cerrarConexion();
            }
        }
    }    
    
    public static Facturas listarFacturasAfiliado(Afiliado afiliado) throws ExcepcionConectar, ExcepcionCerrarConexion, ExcepcionListarFacturas {
        ArrayList<Factura> listafacturas = new ArrayList<>();
        Facturas facturas = new Facturas();
        Connection conexion = PersistenciaConexion.Conectar();

        try {
            PreparedStatement consultaPreparada = conexion.prepareStatement(CONSULTA_AFILIADO);
            consultaPreparada.setString(1, afiliado.getCedula());
            ResultSet resultado = consultaPreparada.executeQuery();
            while (resultado.next()) {
                Factura factura = new Factura();
                factura.setCedulaAfiliado(resultado.getString("afiliadoced"));
                factura.setFechaEmision(resultado.getDate("fecha_emision"));
                factura.setConcepto(resultado.getString("concepto"));
                factura.setFechaPago(resultado.getDate("fecha_pago"));
                factura.setIdentificador(resultado.getInt("idfactura"));
                listafacturas.add(factura);
            }
            facturas.setListaFacturas(listafacturas);
        } catch (SQLException ex) {
            throw new ExcepcionListarFacturas("No se pudo listar facturas");
        } finally {
            PersistenciaConexion.cerrarConexion();
        }
        return facturas;
    }
    
    public static Facturas listarImpagasAfiliado(Afiliado afiliado) throws ExcepcionConectar, ExcepcionCerrarConexion, ExcepcionListarFacturas {
        ArrayList<Factura> listafacturas = new ArrayList<>();
        Facturas facturas = new Facturas();
        Connection conexion = PersistenciaConexion.Conectar();

        try {
            PreparedStatement consultaPreparada = conexion.prepareStatement(CONSULTA_IMPAGAS_AFILIADO);
            consultaPreparada.setString(1, afiliado.getCedula());
            ResultSet resultado = consultaPreparada.executeQuery();
            while (resultado.next()) {
                Factura factura = new Factura();
                factura.setCedulaAfiliado(resultado.getString("afiliadoced"));
                factura.setFechaEmision(resultado.getDate("fecha_emision"));
                factura.setConcepto(resultado.getString("concepto"));
                factura.setFechaPago(resultado.getDate("fecha_pago"));
                factura.setIdentificador(resultado.getInt("idfactura"));
                listafacturas.add(factura);
            }
            facturas.setListaFacturas(listafacturas);
        } catch (SQLException ex) {
            throw new ExcepcionListarFacturas("No se pudo listar facturas");
        } finally {
            PersistenciaConexion.cerrarConexion();
        }
        return facturas;
    }
    
    


    
}
